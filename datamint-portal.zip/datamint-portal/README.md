# DATAMINT AARVIX – Employee Portal

A single-page web app for managing a team: secure OTP sign-in, employee records, daily attendance, task assignment and performance scoring, with separate **Manager** and **Employee** roles.

**Live demo:** _add your Netlify link here_

---

## Tech stack (what I used)

| Layer | Technology | Why |
|---|---|---|
| Structure | **HTML5** | One `index.html`, no build step, deploys anywhere |
| Styling | **CSS3**: CSS variables, Grid, Flexbox, `light-dark()` for automatic dark mode, media queries for mobile | Modern responsive design without a framework |
| Logic | **Vanilla JavaScript (ES2020+)**: modules in one IIFE, async/await, template literals | No framework, fast load, easy to read |
| Routing | Hash-based routing (`#dashboard`, `#tasks` …) | Single-page app with bookmarkable pages |
| Password security | **Web Crypto API**: SHA-256 hash with a random salt per user | Passwords are never stored as plain text |
| OTP codes | `crypto.getRandomValues()` 6-digit codes, 10-min expiry, 5 attempts, 30 s resend cooldown | Two-step login |
| Email delivery | **EmailJS** REST API | Sends the OTP to the user's real inbox without a backend server |
| Database | **Firebase Firestore** (optional), falls back to browser **localStorage** | Shared, real-time data across devices |
| Charts | Hand-written **SVG** (area chart, sparklines, timeline) | No chart library needed |
| Font | Manrope (Google Fonts) | Clean, modern look |
| Hosting | **GitHub** (code) + **Netlify** (auto-deploy on every push) | Free, HTTPS, continuous deployment |

---

## Features

### Authentication
- Sign up with full name, email and password (strength meter, show/hide, validation)
- **Email OTP** to verify the account, and again on every login
- Two roles: **Employee** (default) and **Manager** (needs a secret manager access code)
- "Keep me signed in" option; protected pages redirect to login

### Manager admin (managers only)
- **Dashboard:** total staff, present today, absent, overdue tasks, 14-day attendance trend chart, today's check-in timeline, "who's in today" board
- **Employees:** add / edit / delete / search / filter / sort; auto employee ID (EMP-1001…), roll number, phone, department, salary, joining date and more; CSV export
- **Attendance:** daily register (Present / Half day / Leave / Absent), quick check-in by employee ID, days present per month, monthly CSV
- **Tasks:** assign tasks with priority and due date; board with To do → In progress → Submitted → Done
- **Performance:** rate finished tasks 1–5 stars with feedback; automatic score and grade

### Employee area
- One-click daily check-in
- Days present, 30-day attendance strip, personal score
- My tasks: start a task, submit it for review, see manager ratings and feedback

### Performance score formula
```
score = 50% × (average rating ÷ 5)
      + 25% × (tasks completed ÷ tasks assigned)
      + 25% × (days present ÷ working days this month)
Grade: A ≥ 85, B ≥ 70, C ≥ 50, D < 50
```

---

## How it works (architecture)

```
index.html
 ├─ <style>   design system: colours, layout, components, dark mode
 └─ <script>
     ├─ CONFIG      EmailJS keys, Firebase config, manager code
     ├─ Data layer  put() / del() → Firestore if configured, else localStorage
     │              collections: accounts, employees, attendance, tasks
     ├─ Auth        hash(), startOtp(), sendCode(), finishOtp(), sessions
     ├─ Router      route() reads location.hash, enforces role access
     ├─ Views       landing, auth, manager dashboard, employees, attendance,
     │              tasks, performance, worker dashboard, about
     └─ Events      bindView() wires up buttons and forms after each render
```

Login flow: **email + password → password hash checked → OTP emailed → code verified → session started**.

---

## Setup

1. Open `index.html` and find the `CONFIG` block near the top of the script:
   ```js
   emailjs:{serviceId:'service_xxx',templateId:'template_xxx',publicKey:'xxx'},
   firebase:null,            // paste Firebase web config for shared data
   managerCode:'ADMIN-2026'  // change this
   ```
2. **EmailJS template** (emailjs.com → Email Templates): To Email = `{{to_email}}`, body uses `{{to_name}}`, `{{code}}`, `{{purpose}}`.
3. Without EmailJS keys, the OTP is shown on screen (demo mode).

## Run locally
Just open `index.html` in Chrome, or run `npx serve .`

## Deploy
Push to GitHub → Netlify → *Add new site* → *Import from Git* → pick this repo → Deploy. Every new push redeploys automatically.

---

## Limits and next steps
- Role checks and password hashing run in the browser, which is fine for a demo. For production, move auth to a server (Firebase Auth / Supabase / Node.js + JWT) and add database security rules.
- Without Firebase, data is stored per browser.
- Next ideas: leave requests, payroll slips, push notifications, employee photo upload.
